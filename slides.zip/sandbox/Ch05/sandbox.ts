import {reduce, compose,curry,toUpper,split, toLower,prop,length} from 'ramda'
import  {trace} from '../common/trace';


const m_toUpper = (v:string):[string,string]=>{
    return ["toUpper",v.toUpperCase()]
}
