class: middle,center
<style>
  p { font-size: 150% } 
  li { font-size: 150% } 
  .remark-code {  font-size: 120% }
  .small { font-size: 70% }
</style>

# Reduce

---


# Reduce

FP is all about identifying patterns in our code and extract these patterns into functions. 

<!--- 
from https://medium.com/@zaid.naom/exploring-folds-a-powerful-pattern-of-functional-programming-3036974205c8 by 
--->

---

# Identify common patterns

```typescript
var sum = function(list) {
  var totalSum = 0;
  for(var i = 0; i < list.length; i++) {
      totalSum = totalSum + list[i];
  }
  return totalSum;
};

sum([1, 2, 3]) // 6
```

---

# Identify common patterns

```typescript
var product = function(list) {
  var result = 1;
  for(var i = 0; i < list.length; i++) {
    result = result * list[i];
  }
  return result;
};

product([1, 2, 3, 4, 5]) // 120
```

---

# Identify common patterns

```typescript
var count = function(list) {
  var totalCount = 0;
  for(var i = 0; i < list.length; i++) {
      totalCount = totalCount + 1;
  }
  return totalCount;
}

count([1, 2, 3]) // 3
```

---

# Identify common patterns

```typescript
var forAll = function(list) { 
  var result = true;
  for(var i = 0; i < list.length; i++) {
    result = result && list[i];
  }
  return result;
}
```

---

# Common pattern

* We have the Initial Value (totalSum, result, totalCount etc.) that we are defining at the very beginning. This initial value is also called the Identity Value or the Neutral Element.
* We are going through all the elements within the input list (traversing the list).
* We are doing an Operation inside the for-loop and accumulating the result before returning it.

---

# Extracting the common parts and variables
## Common parts
traversing the list
## Variables
* Initial Value
* Operation

---

# Extracting the common parts and variables

```typescript
type FuncType<S,T> = (cur:S,acc:T) => T

const MyReduce = <S,T>(f : FuncType<S,T>, identity:T, list : S[] ) => {
    var acc = identity;
    for (let i = 0; i < list.length; i++) {
        acc = f(list[i],acc)
    }
    return acc;
}
```

---

# Implements with reduce(1)
```typescript
const _add = (acc:number,cur:number)=>acc+cur;
const MySum = (list:number[])=>MyReduce(_add,0,list)

const _max = <T>(acc:T,cur:T)=>cur>acc?cur:acc
const MyMax = <T>(list:T[])=> MyReduce(_max,list[0],list)

const _length = <T>(cur:T,acc:number) => acc + 1;
const MyLength = <T>(list:T[])=>MyReduce(_length,0,list);
```

---

# Implements with reduce(2)

```typescript
console.log(filter((x:number)=>x>2,[1,2,3,4]))
//[3,4]
```

--

```typescript
// (T,T[]) => T[]
const MyFilter = <T>(pred:(v:T)=>boolean, list:T[]):T[]=>
    MyReduce( (cur:T, acc:T[])=>pred(cur)?[...acc,cur]:acc ,[],list)
console.log(MyFilter((x:number)=>x>2,[1,2,3,4]))
```

---

# Redux

<!---
https://www.freecodecamp.org/news/from-reduce-to-redux-understanding-redux-by-building-redux-918ef08abafe/
--->

* Redux takes a functional approach to modeling data, which challenges the traditional MVC pattern.
* Redux uses reducer functions to manage application state. A Redux-style reducer takes the current state and an action object and returns the new state.

---

# Redux : a state management tool

* We can model application behavior as responses to a stream of actions. 
* Each response to an action return a new application state.

signature of reducer:
(a->b->b) -> b -> [a] -> b

model of application state management 

(action->state->state) -> state -> [actions] -> state

---

# Redux : Counter example in OO style

A counter example in OO style

```typescript
class Counter{
    constructor(){
        this.count = 0;
    }
    count : number

    inc(){
        this.count =  this.count + 1;
    }

    dec(){
        this.count = this.count - 1;
    }
}
```

---

# Redux : Counter example in OO style

```typescript
const counter = new Counter();

counter.inc();
counter.dec();
```

---

# Redux : Counter example in FP style

```typescript
type ActionType = "inc" | "dec" 

const reducer = (state = {count:0}, action:Action<ActionType> ) => {
    switch(action.type){
        case "inc":{
            return {count:state.count+1}
        }  
        case "dec":{
            return {count:state.count-1}
        }
    }
}
```

---

# Redux : Counter example in FP style

1. A reducer called with no parameters should return its valid initial state.
2. If the reducer isn’t going to handle the action type, it still needs to return the state. 
3. Redux reducers must be pure functions.

---

# Redux : Counter example in FP style
```typescript
const store = createStore(reducer)

store.dispatch({type:"inc"})
store.dispatch({type:"dec"})
```

---

# Redux: Benefits 
## Redux makes the state predictable

If the same state and action are passed to a reducer, the same result is always produced as reducers are pure functions.

---

# Redux: Benefits 

Traceable with tools
![image for redux logger](Chapter4_redux_log.png)

---

# Redux: Benefits 

Change state storage strategy, even manage state in server side






