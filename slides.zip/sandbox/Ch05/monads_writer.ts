import {reduce, compose,curry,toUpper,split, toLower,prop,length} from 'ramda'
import { Monad, m_compose3,m_compose } from '../common/monads';
import { trace } from '../common/trace';

class ResultType<T> implements Monad<T>{
    readonly value : [string,T]
    constructor(value:[string,T]){
        this.value = value;
    }

    static of<T>(label:string, value : T){
        return new ResultType([label,value])
    }

    map<F>(func:(v:T)=>F){
        return ResultType.of("map",func(this.value[1]))
    }

    flatmap<F>(func:(v:T)=>ResultType<F>){
        const v = func(this.value[1])
        return ResultType.of([this.value[0],v.value[0]].join(),v.result())
    }

    result():T{
        return this.value[1]
    }
}

const m_toUpper = (v:string) => 
    ResultType.of("toUpper",toUpper(v))
const m_length = (v:string) => 
    ResultType.of("length",v.length)
const m_append = curry((v1:string,v2:string) => 
    ResultType.of("append",v1+v2))

trace(m_toUpper("test").flatmap(m_append(" case")).flatmap(m_length))
trace(m_compose3(m_length,m_append(" case"),m_toUpper)("test"))

//forAll: a=>bool=>[a]=>bool
//reducer : a,bool => bool
const forAll = <T>(pred:(a:T)=>boolean,list:T[]):boolean=>
    reduce((acc:boolean,elem:T):boolean=>acc&&pred(elem),true,list)

console.log(forAll(x=>x>2,[1,2,3,4,]))


